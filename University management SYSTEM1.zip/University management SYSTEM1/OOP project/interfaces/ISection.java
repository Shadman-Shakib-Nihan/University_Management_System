package interfaces;
public interface ISection

{ 
	void insertSectionQuantity(int x);
}