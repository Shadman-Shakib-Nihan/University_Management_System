package interfaces;
public interface IFund
{
   
	void deposit(double amount);
	
}