import java.lang.*;
import classes.*;
import javax.swing.*;
import java.awt.*;
import entity.*;


public class Start {
    public static void main(String[] args) {
       new Welcome();
        
    }
}